#!/bin/sh
chmod u+x dnaCloud.sh
cd source
python MainFrame.py

